package com.heng.roomrental.security.authentication.service;

import com.heng.roomrental.security.authentication.dto.RegisterRequest;
import com.heng.roomrental.user.entity.User;
import com.heng.roomrental.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RegistrationService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailVerificationService emailVerificationService;

    @Transactional
    public void register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.email())) {
            throw new RuntimeException("Email already registered");
        }

        User user = new User();

        user.setEmail(request.email());
        user.setPasswordHash(
                passwordEncoder.encode(request.password())
        );

        user.setFirstName(request.firstName());
        user.setLastName(request.lastName());

        user.setEmailVerified(false);

        userRepository.save(user);

        emailVerificationService.sendOtp(request.email());
    }
}