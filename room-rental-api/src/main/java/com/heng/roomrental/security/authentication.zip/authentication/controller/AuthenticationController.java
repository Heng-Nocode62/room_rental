package com.heng.roomrental.security.authentication.controller;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.heng.roomrental.reservation.dto.ReservationResponse;
import com.heng.roomrental.reservation.service.ReservationService;
import com.heng.roomrental.security.authentication.dto.*;
import com.heng.roomrental.security.authentication.service.AuthenticationService;
import com.heng.roomrental.security.jwt.JwtService;

import com.heng.roomrental.security.refresh.RefreshTokenService;
import com.heng.roomrental.user.entity.User;
import com.heng.roomrental.user.security.UserPrincipal;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthenticationController {

    private final AuthenticationService authenticationService;
    private final GoogleIdTokenVerifier googleVerifier;
    private final JwtService jwtService;
    private final RefreshTokenService refreshTokenService;
    private final ReservationService reservationService;

    @PostMapping("/login")
    public LoginResponse login(
            @Valid
            @RequestBody
            LoginRequest request
    ) {
        return authenticationService.login(request);
    }

    @PostMapping("/refresh")
    public LoginResponse refresh(
            @Valid
            @RequestBody
            RefreshTokenRequest request
    ) {

        return authenticationService.refresh(
                request.refreshToken()
        );
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(
            @Valid
            @RequestBody
            RefreshTokenRequest request
    ) {

        authenticationService.logout(
                request.refreshToken()
        );
    }
    @PostMapping("/google")
    public ResponseEntity<AuthResponse> google(@RequestBody GoogleAuthRequest request) throws GeneralSecurityException, IOException {
        GoogleIdToken idToken = googleVerifier.verify(request.credential());
        if (idToken == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Google token");
        }

        GoogleIdToken.Payload payload = idToken.getPayload();
        if (!Boolean.TRUE.equals(payload.getEmailVerified())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Google email not verified");
        }
        User user = authenticationService.findOrCreateGoogleUser(
                payload.getSubject(),
                payload.getEmail(),
                (String) payload.get("given_name"),
                (String) payload.get("family_name")
        );


        return ResponseEntity.ok(new AuthResponse(
                jwtService.generateAccessToken(UserPrincipal.from(user)),
                refreshTokenService.create(user),
                300l
        ));
    }
    @GetMapping("/me")
    public AuthMeResponse me() {

        return authenticationService.authMe();
    }
    @GetMapping("/me/revervations")
    public List<ReservationResponse> getMyReservation(){
        return reservationService.getMyReservations();
    }

}