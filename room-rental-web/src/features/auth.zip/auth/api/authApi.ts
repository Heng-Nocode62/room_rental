import { api } from "../../../lib/axios";
import type { AuthUser, LoginRequest, LoginResponse } from "../types/auth";

export const authApi = {
  async login(request: LoginRequest): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>("/auth/login", request);

    return response.data;
  },

  async refresh(refreshToken: string): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>("/auth/refresh", {
      refreshToken,
    });

    return response.data;
  },
  async getMe(): Promise<AuthUser> {
    const response = await api.get<AuthUser>("/auth/me");

    return response.data;
  },

  async logout(refreshToken: string): Promise<void> {
    await api.post("/auth/logout", { refreshToken });
  },
   async loginWithGoogle(credential: string): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>("/auth/google", { credential });
    return response.data;
  },
};
