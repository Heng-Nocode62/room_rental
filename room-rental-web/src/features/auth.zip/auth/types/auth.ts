export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  expiresIn: number;
}

export interface AuthUser {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email?: string;
  roles: Role[];
   navigation: NavigationItemResponse[];
}

export interface Role {
  id: number;
  code: string;
  name: string;
  permissions: Permission[];
}

export interface Permission {
  id: number;
  code: string;
  name: string;
  description?: string;
}

export type NavGroup =
  | "application"
  | "setup"
  | "settings";
export interface NavigationItemResponse {
  key: string;
  path: string;
  icon: string;
  group: NavGroup;
  permission?: string | null;
  children?: NavigationItemResponse[] | null;
}