import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

import { Button } from "../../../components/ui/Button";
import { Input } from "../../../components/ui/Input";

import { useLogin } from "../hooks/useLogin";
import { useGoogleLogin } from "../hooks/useGoogleLogin";
import GoogleAuthButton from "../../../components/ui/GoogleAuthButton";

interface LoginFormValues {
  username: string;
  password: string;
}

export default function LoginPage() {
  const navigate = useNavigate();
  const loginMutation = useLogin();
  const googleLoginMutation = useGoogleLogin();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>();

  const goToDashboard = () => navigate("/app", { replace: true });

  const onSubmit = async (values: LoginFormValues) => {
    try {
      await loginMutation.mutateAsync(values);
      goToDashboard();
    } catch {
      // error state handled below
    }
  };

  const handleGoogleAuth = async (credential: string) => {
    try {
      await googleLoginMutation.mutateAsync(credential);
      goToDashboard();
    } catch {
      // error state handled below
    }
  };

  const hasError = loginMutation.isError || googleLoginMutation.isError;

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="mb-8">
          <h1 className="text-2xl font-semibold text-slate-900">Room Rental</h1>
          <p className="mt-1 text-sm text-slate-500">Staff Management Portal</p>
        </div>

        {hasError && (
          <div className="mb-5 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
            Invalid username or password, or Google sign-in failed.
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <Input
            id="username"
            label="Username"
            autoComplete="username"
            placeholder="Enter your username"
            error={errors.username?.message}
            {...register("username", { required: "Username is required" })}
          />

          <Input
            id="password"
            label="Password"
            type="password"
            autoComplete="current-password"
            placeholder="Enter your password"
            error={errors.password?.message}
            {...register("password", { required: "Password is required" })}
          />

          <Button type="submit" loading={loginMutation.isPending}>
            Sign in
          </Button>
        </form>

        <div className="my-5 flex items-center gap-3 text-xs text-slate-400">
          <div className="h-px flex-1 bg-slate-200" />
          OR
          <div className="h-px flex-1 bg-slate-200" />
        </div>

        <GoogleAuthButton onAuth={handleGoogleAuth} />
      </div>
    </div>
  );
}