import { Outlet, NavLink } from "react-router-dom";
import type { ReactNode } from "react";
import { MapPin } from "../../components/ui/MaterialIcon.tsx";

export interface RoleNavItem {
  label: string;
  path: string;
  icon?: ReactNode;
}

interface Props {
  title: string;
  nav: RoleNavItem[];
  locationName?: string;
  locations?: Array<{ id: number; name: string }>;
  currentLocationId?: number | null;
  onLocationChange?: (id: number) => void;
  children?: ReactNode;
}

export default function RoleLayoutShell({
  title,
  nav,
  locationName,
  locations,
  currentLocationId,
  onLocationChange,
}: Props) {
  return (
    <div className="min-h-screen bg-slate-50">
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-slate-200 bg-white lg:block">
        <div className="border-b border-slate-200 px-5 py-5">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Room Rental</p>
          <h1 className="mt-1 text-lg font-semibold text-slate-900">{title}</h1>
        </div>
        <nav className="space-y-1 p-3">
          {nav.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                  isActive ? "bg-slate-100 text-slate-900" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`
              }
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
          <div className="flex min-h-16 items-center justify-between gap-4 px-5 sm:px-6">
            <div>
              <p className="text-sm font-semibold text-slate-900">{title}</p>
              {locationName && <p className="text-xs text-slate-500">{locationName}</p>}
            </div>
            {locations && locations.length > 0 && currentLocationId && onLocationChange && (
              <label className="flex items-center gap-2 text-sm">
                <MapPin size={18} className="text-slate-500" />
                <select
                  className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus:border-slate-400"
                  value={currentLocationId}
                  onChange={(event) => onLocationChange(Number(event.target.value))}
                >
                  {locations.map((location) => (
                    <option key={location.id} value={location.id}>{location.name}</option>
                  ))}
                </select>
              </label>
            )}
          </div>
        </header>
        <main className="p-5 sm:p-6"><Outlet /></main>
      </div>
    </div>
  );
}
