import { useNavigate } from "react-router-dom";

import { Button } from "../ui/Button";
import { usePermissions } from "../../features/auth/hooks/usePermissions";
import { useLogout } from "../../features/auth/hooks/useLogout";
import LanguageSwitcher from "../../features/settings/LanguageSwitcher";
import { useAppConfig } from "../../features/settings/context/AppConfigProvider";
import LocationSwitcher from "../../features/location-scope/LocationScopeSwitcher";
import UserMenu from "./UserMenu";

/** Top bar for the vertical (sidebar) layout. The horizontal layout uses HorizontalHeader. */
export default function Header() {
  const navigate = useNavigate();
  const { user } = usePermissions();
  const logoutMutation = useLogout();
  const { config } = useAppConfig();

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();

    navigate("/login", { replace: true });
  };

  return (
    <header className="flex h-16 items-center justify-end border-b border-slate-200 bg-white px-6">
      <div className="flex items-center gap-4">
        
        <LocationSwitcher />
        <LanguageSwitcher />
        <UserMenu />

        <Button
          variant="ghost"
          onClick={handleLogout}
          loading={logoutMutation.isPending}
        >
          Logout
        </Button>
      </div>
    </header>
  );
}
