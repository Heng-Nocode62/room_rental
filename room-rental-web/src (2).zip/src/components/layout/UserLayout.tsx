import { CalendarCheck, CalendarDays, ClipboardList, Settings2 } from "../../components/ui/MaterialIcon.tsx";
import RoleLayoutShell, { type RoleNavItem } from "./RoleLayoutShell";

const nav: RoleNavItem[] = [
  { label: "Dashboard", path: "/user/dashboard", icon: <Settings2 size={18} /> },
  { label: "My Reservations", path: "/user/reservations", icon: <ClipboardList size={18} /> },
  { label: "Hourly Availability", path: "/availability/hourly", icon: <CalendarCheck size={18} /> },
  { label: "Daily Availability", path: "/availability/daily", icon: <CalendarDays size={18} /> },
  { label: "My Profile", path: "/user/profile", icon: <Settings2 size={18} /> },
];

export default function UserLayout() {
  return <RoleLayoutShell title="User" nav={nav} />;
}
