import { MapPin } from "../../components/ui/MaterialIcon.tsx";
import { useOptionalLocationScope } from "./LocationScopeProvider";

export default function LocationSwitcher() {
  const scope = useOptionalLocationScope();

  if (!scope || scope.locations.length === 0 || !scope.currentLocationId) {
    return null;
  }

  return (
    <label className="flex min-w-0 items-center gap-2 text-sm">
      <MapPin size={16} className="shrink-0 text-slate-500" />
      <select
        className="max-w-[9rem] truncate rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-700 outline-none focus:border-slate-400 sm:max-w-xs"
        value={scope.currentLocationId}
        onChange={(e) => scope.setCurrentLocationId(Number(e.target.value))}
      >
        {scope.locations.map((l) => (
          <option key={l.id} value={l.id}>
            {l.name}
          </option>
        ))}
      </select>
    </label>
  );
}